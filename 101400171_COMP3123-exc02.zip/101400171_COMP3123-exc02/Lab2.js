// Justin Yeh
// 101400171
// COMP 3123

// Exercise 1
const greeter = (myArray, counter) => {
    let greeting = 'Hello';

    for (let name of myArray){
        console.log(`${greeting} ${name}`)
    }
};

greeter(['Randy Savage', 'Ric Flair', 'Hulk Hogan'], 3);

// Exercise 2
const capitalize = ([firstLetter, ...nextLetters]) => { 
    return firstLetter.toUpperCase() + nextLetters.join('').toLowerCase()
};
console.log(capitalize('fooBar'));
console.log(capitalize('nodeJs'));

// Exercise 3
const colors = ['red', 'green', 'blue'];
let capitalizedColors = colors.map(eachColor => capitalize(eachColor));
console.log(capitalizedColors);

// Exercise 4
const values = [1, 60, 34, 30, 20, 5];
let filteredValues = values.filter(num => num < 20);
console.log(filteredValues);

// Exercise 5
const numberArray = [1, 2, 3, 4]
const calculateSum = (sumTotal, variable) => sumTotal + variable;
console.log(numberArray.reduce(calculateSum));


const calculateProduct = (productTotal, variable) => productTotal * variable;
console.log(numberArray.reduce(calculateProduct));

// Exercise 6
class Car {
    constructor(model, year){
        this.model = model;
        this.year = year;
    }
    setModel(m) {this.model=m}
    getModel() {return this.model}
    setYear(y) {this.year=y}
    getYear() {return this.year}
    details() {
        var carDesc = `Model: ${this.model} Engine ${this.year}`;
        return carDesc;
    }
}

const car = new Car('Pontiac Firebird', 1976);
console.log(car.details());

class Sedan extends Car {
    constructor(model, year, balance) {
        super(model, year);
        this.balance = balance;
    }
    info() {
        var result = `${this.model} has a balance of $${this.balance.toFixed(2)}`
        return result
    }
}

const sedan = new Sedan('Volvo SF', 2018, 30000);
console.log(sedan.info());

