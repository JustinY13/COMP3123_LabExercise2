class Car {
    constructor(model, year){
        this.model = model;
        this.year = year;
    }
    setModel(m) {this.model=m}
    getModel() {return this.model}
    setYear(y) {this.year=y}
    getYear() {return this.year}
    details() {
        var carDesc = `Model: ${this.model} Engine ${this.year}`;
        return carDesc;
    }
}

const car = new Car('Pontiac Firebird', 1976);
console.log(car.details());

class Sedan extends Car {
    constructor(model, year, balance) {
        super(model, year);
        this.balance = balance;
    }
    info() {
        var result = `${this.model} has a balance of $${this.balance.toFixed(2)}`
        return result
    }
}

const sedan = new Sedan('Volvo SF', 2018, 30000);
console.log(sedan.info());